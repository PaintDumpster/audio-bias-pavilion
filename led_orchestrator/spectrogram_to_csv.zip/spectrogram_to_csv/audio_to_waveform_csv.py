import numpy as np
import librosa
import csv

AUDIO_PATH = "audio.wav"          # convert mp4->wav like before
OUTPUT_CSV = "waveform.csv"

N_STRIPS = 146
N_LEDS_VERTICAL = 42              # match GH (42)
DURATION_LIMIT = None             # set 30 for 30 sec, or None for full audio

# 1) Load audio
y, sr = librosa.load(AUDIO_PATH, sr=None, mono=True)

if DURATION_LIMIT:
    y = y[:int(DURATION_LIMIT * sr)]

# 2) Compute amplitude envelope (RMS) over time
# hop_length controls how smooth it is; we'll resample to N_STRIPS anyway
frame_length = 2048
hop_length = 512
rms = librosa.feature.rms(y=y, frame_length=frame_length, hop_length=hop_length)[0]  # shape (T,)

# 3) Normalize (robust)
# Use percentile to avoid one loud spike flattening everything
lo = np.percentile(rms, 5)
hi = np.percentile(rms, 95)
rms_n = (rms - lo) / (hi - lo + 1e-9)
rms_n = np.clip(rms_n, 0, 1)

# 4) Resample to exactly N_STRIPS (one value per strip)
idx = np.linspace(0, len(rms_n) - 1, N_STRIPS).astype(int)
amp = rms_n[idx]  # shape (N_STRIPS,)

# 5) Convert each amplitude into a vertical LED bar (matrix N_STRIPS x N_LEDS_VERTICAL)
# WhatsApp style usually draws from a center line; choose one:
CENTERED = True   # True = bar expands from middle, False = from bottom

mat = np.zeros((N_STRIPS, N_LEDS_VERTICAL), dtype=float)

for i in range(N_STRIPS):
    h = int(round(amp[i] * (N_LEDS_VERTICAL - 1)))

    if CENTERED:
        mid = (N_LEDS_VERTICAL - 1) / 2.0
        half = h / 2.0
        lo_i = int(max(0, np.floor(mid - half)))
        hi_i = int(min(N_LEDS_VERTICAL - 1, np.ceil(mid + half)))
        mat[i, lo_i:hi_i+1] = 1.0
    else:
        mat[i, 0:h+1] = 1.0

# 6) Save CSV
with open(OUTPUT_CSV, "w", newline="") as f:
    w = csv.writer(f)
    w.writerows(mat.tolist())

print("Saved", OUTPUT_CSV, "shape:", mat.shape)
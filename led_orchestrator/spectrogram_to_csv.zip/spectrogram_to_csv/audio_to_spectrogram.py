import numpy as np
import librosa
import csv

# ---------- SETTINGS ----------
AUDIO_PATH = "audio.wav"        # Your audio file name
OUTPUT_CSV = "spectrogram.csv"

N_STRIPS = 146                  # Replace with your GH strip count
N_LEDS_VERTICAL = 42            # 60 px/m × 0.70m = 42
DURATION_LIMIT = None           # Optional: set to 30 for 30 sec
# --------------------------------

# Load audio
y, sr = librosa.load(AUDIO_PATH, sr=None, mono=True)

# Optional trim
if DURATION_LIMIT:
    y = y[:int(DURATION_LIMIT * sr)]

# Create mel spectrogram
S = librosa.feature.melspectrogram(
    y=y,
    sr=sr,
    n_mels=128,
    fmin=50,
    fmax=8000
)

# Convert to decibels
S_db = librosa.power_to_db(S, ref=np.max)

# Normalize to 0..1
S_norm = (S_db - S_db.min()) / (S_db.max() - S_db.min() + 1e-9)

# Transpose so rows = time, columns = frequency
S_tf = S_norm.T

# Resize frequency bins to LED height
freq_idx = np.linspace(0, S_tf.shape[1]-1, N_LEDS_VERTICAL).astype(int)
S_tf = S_tf[:, freq_idx]

# Resize time frames to match strip count
time_idx = np.linspace(0, S_tf.shape[0]-1, N_STRIPS).astype(int)
S_tf = S_tf[time_idx, :]

# Save CSV
with open(OUTPUT_CSV, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(S_tf)

print("Done.")
print("CSV shape:", S_tf.shape)